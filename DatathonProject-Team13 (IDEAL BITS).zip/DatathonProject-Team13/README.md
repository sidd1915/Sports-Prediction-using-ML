1.Initially run main.py
 Install pandas , nltk packages

2.Run train file
 Install scikit-learn packages

3.Run test.py

4.Run sentiment.py

5.Run accuracy.py

6.Run invalid.py