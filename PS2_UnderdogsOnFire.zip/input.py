from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from threading import Thread
import time
from model import load_model, load_transformer_values
import pandas as pd

app = Flask(__name__)
CORS(app)

model = None
transformer_values = None

winloss_team_names = [
    "CSK", "DC", "GT", "KKR", "KXIP",
    "LSG", "MI", "RCB", "RR", "SRH"
]

winloss_opp_teams = [
    "CSK", "DC", "GL", "GT", "KKR",
    "KXIP", "Kochi", "LSG", "MI", "PBKS",
    "PWI", "RCB", "RPS", "RR", "SRH"
]

winloss_venues = [
    "Arun Jaitley Stadium, Delhi", "Barabati Stadium, Cuttack",
    "Barsapara Cricket Stadium, Guwahati", "Bharat Ratna Shri Atal Bihari Vajpayee Ekana Cricket Stadium, Lucknow",
    "Brabourne Stadium, Mumbai", "Buffalo Park, East London",
    "Diamond Oval, Kimberley", "Dr DY Patil Sports Academy, Mumbai",
    "Dr DY Patil Sports Academy, Navi Mumbai", "Dr. Y.S. Rajasekhara Reddy ACA-VDCA Cricket Stadium, Visakhapatnam",
    "Dubai International Cricket Stadium", "Eden Gardens, Kolkata",
    "Green Park, Kanpur", "Himachal Pradesh Cricket Association Stadium, Dharamsala",
    "Holkar Cricket Stadium, Indore", "JSCA International Stadium Complex, Ranchi",
    "Kingsmead, Durban", "M.Chinnaswamy Stadium, Bengaluru",
    "MA Chidambaram Stadium, Chepauk, Chennai", "Maharashtra Cricket Association Stadium, Pune",
    "Mangaung Oval, Bloemfontein", "Narendra Modi Stadium, Motera, Ahmedabad",
    "Nehru Stadium, Kochi", "Newlands, Cape Town",
    "Punjab Cricket Association IS Bindra Stadium, Mohali, Chandigarh", "Rajiv Gandhi International Stadium, Uppal, Hyderabad",
    "Sardar Patel (Gujarat) Stadium, Motera, Ahmedabad", "Saurashtra Cricket Association Stadium, Rajkot",
    "Sawai Mansingh Stadium, Jaipur", "Shaheed Veer Narayan Singh International Stadium, Raipur",
    "Sharjah Cricket Stadium", "Sheikh Zayed Stadium, Abu Dhabi",
    "St George's Park, Port Elizabeth", "SuperSport Park, Centurion",
    "The Wanderers Stadium, Johannesburg", "Vidarbha Cricket Association Stadium, Jamtha, Nagpur",
    "Wankhede Stadium, Mumbai"
]

winloss_toss_decisions = ["bat", "bowl"]

winloss_toss_won = [0, 1]


def predict(input_data):
    global model
    if not model:
        return {"error": "Model not loaded"}
    else:
        return {"prediction": model.predict(pd.json_normalize(input_data))}


# Background thread to load the model
model_thread = Thread(target=load_model)
model_thread.start()


@app.route('/')
def index():
    return 'Welcome to the Prediction App!'


@app.route('/winloss', methods=['GET'])
def winloss():
    return render_template('winloss.html', team_names=winloss_team_names, opp_teams=winloss_opp_teams, venues=winloss_venues, toss_decisions=winloss_toss_decisions, toss_won=winloss_toss_won)


@app.route('/scoreipl', methods=['GET'])
def scoreipl():
    return render_template('scoreipl.html', team_names=winloss_team_names, opp_teams=winloss_opp_teams, venues=winloss_venues, toss_decisions=winloss_toss_decisions, toss_won=winloss_toss_won)


@app.route('/predict', methods=['POST'])
def make_prediction():
    global transformer_values
    if request.method == 'POST':
        request_data = request.get_json()
        input_data = request_data  # type: dict
        print(input_data)
        for key, value in input_data.items():
            if key in transformer_values:
                input_data[key] = transformer_values[key].index(value)  # list
        print(input_data)
        prediction_result = predict(input_data)
        print(prediction_result)
        return jsonify(prediction_result)


if __name__ == '__main__':
    print("Model Loading Started")
    model = load_model()
    print("Model Loaded Successfully")

    print("Loading Transformer Values")
    transformer_values = load_transformer_values()
    print("Transformer Values Loaded Successfully")

    app.run(debug=True, port=5000, host='0.0.0.0')
