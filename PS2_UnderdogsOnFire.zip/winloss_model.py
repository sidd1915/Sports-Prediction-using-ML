from lazypredict.Supervised import LazyRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import pandas as pd
import numpy as np
import pickle
import json

df_all_season_summary = pd.read_csv('data/all_season_summary_cleaned.csv')


def runs(match_id, team_name):
    try:
        if df_all_season_summary[df_all_season_summary['id'] == match_id]['home_team'].values[0] == team_name:
            runs_scored = df_all_season_summary[df_all_season_summary['id']
                                                == match_id]['home_score'].values[0]
        else:
            runs_scored = df_all_season_summary[df_all_season_summary['id']
                                                == match_id]['away_score'].values[0]
        if "/" in str(runs_scored):
            runs_scored = int(runs_scored.split("/")[0])
        return int(runs_scored)
    except:
        return 0


def batting_stats():

    df = pd.read_csv('data/all_season_batting_card.csv')

    df = df[['season', 'match_id', 'current_innings', 'runs',
            'ballsFaced', 'fours', 'sixes', 'strikeRate']]

    # team wise batting performance

    team_wise_batting = df.groupby(['season', 'match_id', 'current_innings']).agg(
        {'runs': 'sum', 'ballsFaced': 'sum', 'fours': 'sum', 'sixes': 'sum'}).reset_index()
    team_wise_batting['batting_strike_rate'] = (
        team_wise_batting['runs'] / team_wise_batting['ballsFaced']) * 100

    team_wise_batting.rename(columns={'ballsFaced': 'balls_faced', 'current_innings': 'team_name',
                                      'runs': 'batting_runs', 'fours': 'batting_fours', 'sixes': 'batting_sixes'}, inplace=True)

    for index, row in team_wise_batting.iterrows():
        match_id = row['match_id']
        team_name = row['team_name']
        runs_scored = runs(match_id, team_name)
        team_wise_batting.loc[index, 'batting_runs'] = runs(
            match_id, team_name)

    team_wise_batting.to_csv('gen/team_wise_batting.csv', index=False)


def bowling_stats():
    df = pd.read_csv('data/all_season_bowling_card.csv')

    df = df[['season', 'match_id', 'wickets', 'bowling_team', 'conceded', 'overs', 'maidens',
            'wides', 'noballs', 'sixesConceded', 'foursConceded', 'dots', 'economyRate']]

    # team wise bowling performance

    team_wise_bowling = df.groupby(['season', 'match_id', 'bowling_team']).agg(
        {'conceded': 'sum', 'overs': 'sum', 'maidens': 'sum', 'wides': 'sum', 'noballs': 'sum', 'wickets': 'sum', 'sixesConceded': 'sum', 'foursConceded': 'sum', 'dots': 'sum'}).reset_index()

    team_wise_bowling['economy_rate'] = (
        team_wise_bowling['conceded'] / team_wise_bowling['overs'])

    team_wise_bowling['bowling_strike_rate'] = (
        team_wise_bowling['overs'] / team_wise_bowling['wickets']) * 6

    team_wise_bowling['bowling_average'] = (
        team_wise_bowling['conceded'] / team_wise_bowling['wickets'])

    team_wise_bowling['bowling_average'] = team_wise_bowling['bowling_average'].replace(
        np.inf, 0)
    team_wise_bowling['bowling_strike_rate'] = team_wise_bowling['bowling_strike_rate'].replace(
        np.inf, 0)

    team_wise_bowling.rename(columns={'bowling_team': 'team_name', 'conceded': 'bowling_runs',
                                      'foursConceded': 'bowling_fours', 'sixesConceded': 'bowling_sixes'}, inplace=True)

    team_wise_bowling.to_csv('gen/team_wise_bowling.csv', index=False)


def team_wise_match_overview():
    team_wise_batting = pd.read_csv('gen/team_wise_batting.csv')
    team_wise_bowling = pd.read_csv('gen/team_wise_bowling.csv')
    match_wise_overview = pd.merge(team_wise_batting, team_wise_bowling, on=[
        'season', 'match_id', 'team_name'], how='inner')

    match_wise_overview.to_csv(
        'gen/team_wise_match_performance.csv', index=False)


def pretrain_clean():
    df_summary_cleaned = pd.read_csv('data/all_season_summary_cleaned.csv')
    match_wise_overview = pd.read_csv('gen/team_wise_match_performance.csv')
    df_summary_cleaned.rename(columns={'id': 'match_id'}, inplace=True)
    winner_teams = df_summary_cleaned[['season', 'match_id', 'winner',
                                       'home_team', 'away_team', 'toss_won', 'decision', 'venue_name']]

    winner_teams.rename(columns={'decision': 'toss_decision'}, inplace=True)

    total_team_wise = pd.merge(match_wise_overview, winner_teams, on=[
        'season', 'match_id'], how='inner')

    total_team_wise['toss_decision'] = total_team_wise['toss_decision'].str.lower(
    ).str.replace('first', '').str.strip()

    total_team_wise['toss_won'] = total_team_wise['toss_won'] == total_team_wise['team_name']

    total_team_wise['opp_team'] = ''

    for index, row in total_team_wise.iterrows():
        if row['team_name'] == row['home_team']:
            total_team_wise.loc[index, 'opp_team'] = row['away_team']
        else:
            total_team_wise.loc[index, 'opp_team'] = row['home_team']

    total_team_wise['is_home_team'] = total_team_wise['team_name'] == total_team_wise['home_team']

    total_team_wise['winner'] = total_team_wise['team_name'] == total_team_wise['winner']

    columns = ['team_name']

    total_team_wise = total_team_wise.drop(columns=['home_team', 'away_team'])

    total_team_wise[columns] = total_team_wise[columns].astype('category')

    total_team_wise.to_csv('gen/total_team_wise.csv', index=False)

    return total_team_wise


def pretrain():
    batting_stats()
    bowling_stats()
    team_wise_match_overview()
    return pretrain_clean()


def train_test():

    total_team_wise = pretrain()

    teams = ["RCB",
             "CSK",
             "MI",
             "KKR",
             "DC",
             "KXIP",
             "RR",
             "SRH",
             "GT",
             "LSG"
             ]

    total_team_wise = total_team_wise[total_team_wise['team_name'].isin(teams)].replace({
        True: 1, False: 0})

    remove_columns = ['season', 'match_id', 'bowling_runs',
                      'overs', 'maidens', 'wides', 'noballs', 'wickets', 'bowling_sixes',
                      'bowling_fours', 'dots']

    transform_columns = ['team_name', 'opp_team',
                         'venue_name', 'toss_decision', 'toss_won']
    transformers = {}

    for column in transform_columns:
        transformers[column] = LabelEncoder()

    total_team_wise.drop(columns=remove_columns, inplace=True)

    transformers_values = {}

    for column in transform_columns:
        total_team_wise[column] = transformers[column].fit_transform(
            total_team_wise[column])

        transformers_values[column] = transformers[column].classes_.tolist()

    with open('gen/transformers.json', 'w') as f:
        json.dump(transformers_values, f)

    total_team_wise.columns
    X = total_team_wise.drop(columns=['winner'])
    Y = total_team_wise['winner']

    X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.3)

    clf = LazyRegressor(verbose=1, ignore_warnings=False, custom_metric=None)
    train, test = clf.fit(X_train, X_test, Y_train, Y_test)
    print(train)
    print(test)

    for column in transform_columns:
        print(transformers[column].inverse_transform([0]))

    pickle.dump(clf.models['ExtraTreesRegressor'],
                open('gen/ETRWinLoss.pkl', 'wb'))

    clf.models['ExtraTreesRegressor'].predict(pd.json_normalize({'team_name': 0.0,
                                                                'batting_runs': 109.0,
                                                                 'balls_faced': 114.0,
                                                                 'batting_fours': 12.0,
                                                                 'batting_sixes': 1.0,
                                                                 'batting_strike_rate': 89.47368421052632,
                                                                 'economy_rate': 7.323943661971831,
                                                                 'bowling_strike_rate': 42.599999999999994,
                                                                 'bowling_average': 52.0,
                                                                 'toss_won': 0.0,
                                                                 'toss_decision': 0.0,
                                                                 'venue_name': 28.0,
                                                                 'opp_team': 13.0,
                                                                 'is_home_team': 0.0}))


def load_model():
    return pickle.load(open('gen/ETRWinLoss.pkl', 'rb'))


def load_transformer_values():

    with open('gen/transformers.json') as f:
        transformer_values = json.load(f)

    return transformer_values


if __name__ == '__main__':
    train_test()

    # model = load_model()

    # print(model.predict(pd.json_normalize({'team_name': 0.0,
    #                                        'batting_runs': 109.0,
    #                                        'balls_faced': 114.0,
    #                                        'batting_fours': 12.0,
    #                                        'batting_sixes': 1.0,
    #                                        'batting_strike_rate': 89.47368421052632,
    #                                        'economy_rate': 7.323943661971831,
    #                                        'bowling_strike_rate': 42.599999999999994,
    #                                        'bowling_average': 52.0,
    #                                        'toss_won': 0.0,
    #                                        'toss_decision': 0.0,
    #                                        'venue_name': 28.0,
    #                                        'opp_team': 13.0,
    #                                        'is_home_team': 0.0})))
