# -*- coding: utf-8 -*-
"""
Created on Thu Apr  4 19:07:28 2024

@author: Shivali
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Apr  4 18:00:08 2024

@author: Shivali
"""

import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder

df = pd.read_csv("C:/Users/Shivali/Downloads/Bank Account Fraud.csv")
df.head()

df.replace(-1, pd.NA, inplace=True)
missing_values = df.isnull().sum()
print("Column wise missing values")
print(missing_values)


# Filling missing values for 'keep_alive_session' with mode imputer
mode_value = df['keep_alive_session'].mode()[0]
df['keep_alive_session'].fillna(mode_value, inplace=True)

# Specify the attributes and perform median imputation
attributes_to_impute = ['device_fraud_count', 'month', 'credit_risk_score', 'prev_address_months_count', 'current_address_months_count', 'bank_months_count', 'session_length_in_minutes', 'device_distinct_emails_8w']

# Convert the dataframe to numeric to avoid 'NAType' error
df[attributes_to_impute] = df[attributes_to_impute].apply(pd.to_numeric, errors='coerce')

# Initialize the SimpleImputer with 'median'
imputer = SimpleImputer(strategy='median')

# perform median imputation
for attribute in attributes_to_impute:
    df[attribute] = imputer.fit_transform(df[[attribute]])

# Verifying that missing values have been filled
print("Number of missing values after imputation:")
print(df[attributes_to_impute].isnull().sum())


#To plot histograms to interpret the attributes
import matplotlib.pyplot as plt
df.hist(bins=50,figsize=(20,15))
plt.show()


#To encode categorical data
import category_encoders as ce

#For balancing the dataset

from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.model_selection import StratifiedKFold
from category_encoders import TargetEncoder
from imblearn.over_sampling import ADASYN
from imblearn.under_sampling import NearMiss


attributes = [
    'income', 'name_email_similarity', 'prev_address_months_count', 'current_address_months_count', 
    'customer_age', 'days_since_request', 'intended_balcon_amount', 'zip_count_4w', 'velocity_6h', 
    'velocity_24h', 'velocity_4w', 'bank_branch_count_8w', 'date_of_birth_distinct_emails_4w', 
    'credit_risk_score', 'bank_months_count', 'proposed_credit_limit', 'session_length_in_minutes', 
    'device_distinct_emails_8w', 'device_fraud_count', 'month', 
    'employment_status', 'housing_status', 'payment_type', 'source'
]

# Creating new DataFrame X containing the specified attributes
X = df[attributes].copy()
y = df['fraud_bool']
# Target encoding
target_encoder = TargetEncoder()
X_encoded = target_encoder.fit_transform(X, y)

# Split the original dataset into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X_encoded, y, test_size=0.2, random_state=42)

# Applying oversampling (ADASYN) only to the train set
adasyn = ADASYN(random_state=42)
X_train_oversampled, y_train_oversampled = adasyn.fit_resample(X_train, y_train)
print("hi")
# Apply undersampling (NearMiss) to both train and test sets
'''nearmiss = NearMiss(version=1)
X_train_balanced, y_train_balanced = nearmiss.fit_resample(X_train_oversampled, y_train_oversampled)
X_test_balanced, y_test_balanced = nearmiss.fit_resample(X_test, y_test)
print("hi")
# Now you can use X_train_balanced, y_train_balanced for training your model
# and X_test_balanced, y_test_balanced for testing/evaluating your model

# Example: Cross-validation
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
print("hi")
for train_index, val_index in skf.split(X_train_balanced, y_train_balanced):
    X_train_cv, X_val_cv = X_train_balanced.iloc[train_index], X_train_balanced.iloc[val_index]
    y_train_cv, y_val_cv = y_train_balanced.iloc[train_index], y_train_balanced.iloc[val_index]

    # Your model training and evaluation code here
    # e.g., model.fit(X_train_cv, y_train_cv), model.predict(X_val_cv), etc.'''
    
    


from catboost import CatBoostClassifier

# Initializing CatBoost model
cat_model = CatBoostClassifier()

# Training the model
cat_model.fit(X_train_oversampled, y_train_oversampled)

# Making predictions
cat_pred = cat_model.predict_proba(X_test)[:, 1]
from sklearn.metrics import roc_auc_score

# Calculating ROC-AUC for CatBoost
cat_auc = roc_auc_score(y_test, cat_pred)
print("CatBoost ROC-AUC:", cat_auc)

import lightgbm as lgb

# Initializing LightGBM model
lgb_model = lgb.LGBMClassifier()

# Training the model
lgb_model.fit(X_train_oversampled, y_train_oversampled)

# Making predictions
lgb_pred = lgb_model.predict_proba(X_test)[:, 1]
from sklearn.metrics import roc_auc_score
lgb_auc = roc_auc_score(y_test, lgb_pred)

print("LightGBM ROC-AUC:", lgb_auc)

import xgboost as xgb
from sklearn.metrics import roc_auc_score
# Initializing XGBoost model
xgb_model = xgb.XGBClassifier()

# # Training the model
xgb_model.fit(X_train_oversampled, y_train_oversampled)

# # Makiking predictions
xgb_pred = xgb_model.predict_proba(X_test)[:, 1]
from sklearn.metrics import roc_auc_score
# Calculating ROC-AUC for XGBoost
xgb_auc = roc_auc_score(y_test, xgb_pred)
print("XGBoost ROC-AUC:", xgb_auc)

#OUTPUT CATBOOST
'''970:	learn: 0.0241807	total: 3m 18s	remaining: 5.92s
971:	learn: 0.0241744	total: 3m 18s	remaining: 5.72s
972:	learn: 0.0241607	total: 3m 18s	remaining: 5.52s
973:	learn: 0.0241602	total: 3m 18s	remaining: 5.31s
974:	learn: 0.0241459	total: 3m 19s	remaining: 5.11s
975:	learn: 0.0241296	total: 3m 19s	remaining: 4.91s
976:	learn: 0.0241295	total: 3m 19s	remaining: 4.7s
977:	learn: 0.0241295	total: 3m 19s	remaining: 4.5s
978:	learn: 0.0241294	total: 3m 20s	remaining: 4.29s
979:	learn: 0.0241293	total: 3m 20s	remaining: 4.09s
980:	learn: 0.0241292	total: 3m 20s	remaining: 3.88s
981:	learn: 0.0241233	total: 3m 20s	remaining: 3.68s
982:	learn: 0.0241135	total: 3m 21s	remaining: 3.48s
983:	learn: 0.0241028	total: 3m 21s	remaining: 3.27s
984:	learn: 0.0241027	total: 3m 21s	remaining: 3.07s
985:	learn: 0.0241027	total: 3m 21s	remaining: 2.86s
986:	learn: 0.0241022	total: 3m 21s	remaining: 2.66s
987:	learn: 0.0241021	total: 3m 22s	remaining: 2.45s
988:	learn: 0.0241020	total: 3m 22s	remaining: 2.25s
989:	learn: 0.0241020	total: 3m 22s	remaining: 2.04s
990:	learn: 0.0241017	total: 3m 22s	remaining: 1.84s
991:	learn: 0.0241000	total: 3m 22s	remaining: 1.64s
992:	learn: 0.0240915	total: 3m 22s	remaining: 1.43s
993:	learn: 0.0240915	total: 3m 23s	remaining: 1.23s
994:	learn: 0.0240915	total: 3m 23s	remaining: 1.02s
995:	learn: 0.0240827	total: 3m 23s	remaining: 818ms
996:	learn: 0.0240731	total: 3m 23s	remaining: 613ms
997:	learn: 0.0240645	total: 3m 24s	remaining: 409ms
998:	learn: 0.0240644	total: 3m 24s	remaining: 204ms
999:	learn: 0.0240643	total: 3m 24s	remaining: 0us
CatBoost ROC-AUC: 0.857091771468878
'''

#OUTPUT LightGBM
'''
[LightGBM] [Info] Number of positive: 791416, number of negative: 791080
[LightGBM] [Info] Auto-choosing row-wise multi-threading, the overhead of testing was 0.053083 seconds.
You can set `force_row_wise=true` to remove the overhead.
And if memory is not enough, you can set `force_col_wise=true`.
[LightGBM] [Info] Total Bins 5394
[LightGBM] [Info] Number of data points in the train set: 1582496, number of used features: 23
[LightGBM] [Info] [binary:BoostFromScore]: pavg=0.500106 -> initscore=0.000425
[LightGBM] [Info] Start training from score 0.000425
LightGBM ROC-AUC: 0.8421955178811491'''

#OUTPUT xGBOOST
'''
XGBoost ROC-AUC: 0.8436894206831619
'''
