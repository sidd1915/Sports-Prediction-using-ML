import pandas as pd
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder

# Read the CSV file into a DataFrame
df = pd.read_csv('bankaccfraud.csv')

# Display the DataFrame
print(df.head())


# computing number of rows
rows = len(df.axes[0])

# computing number of columns
cols = len(df.axes[1])

print("Number of Rows: ", rows)
print("Number of Columns: ", cols)


df.head()

# OUTPUT
# PS C:\Users\anush\OneDrive\Desktop\Datathon Extreme> & "C:/Program Files/Python312/python.exe" "c:/Users/anush/OneDrive/Desktop/Datathon Extreme/main.py"
#    fraud_bool  income  name_email_similarity  prev_address_months_count  ...  keep_alive_session  device_distinct_emails_8w  device_fraud_count  month
# 0           0     0.3               0.986506                         -1  ...                   1                          1                   0      0
# 1           0     0.8               0.617426                         -1  ...                   1                          1                   0      0
# 2           0     0.8               0.996707                          9  ...                   0                          1                   0      0
# 3           0     0.6               0.475100                         11  ...                   1                          1                   0      0
# 4           0     0.9               0.842307                         -1  ...                   0                          1                   0      0

# [5 rows x 32 columns]
# Number of Rows:  1000000
# Number of Columns:  32

df.replace(-1,pd.NA,inplace=True)

m = df.isnull().sum()
print(m)

# OUTPUT
# [5 rows x 32 columns]
# Number of Rows:  1000000
# Number of Columns:  32
# fraud_bool                               0
# income                                   0
# name_email_similarity                    0
# prev_address_months_count           712920
# current_address_months_count          4254
# customer_age                             0
# days_since_request                       0
# intended_balcon_amount                   0
# payment_type                             0
# zip_count_4w                             0
# velocity_6h                              0
# velocity_24h                             0
# velocity_4w                              0
# bank_branch_count_8w                     0
# date_of_birth_distinct_emails_4w         0
# employment_status                        0
# credit_risk_score                      488
# email_is_free                            0
# housing_status                           0
# phone_home_valid                         0
# phone_mobile_valid                       0
# bank_months_count                   253635
# has_other_cards                          0
# proposed_credit_limit                    0
# foreign_request                          0
# source                                   0
# session_length_in_minutes             2015
# device_os                                0
# keep_alive_session                       0
# device_distinct_emails_8w              359
# device_fraud_count                       0
# month                                    0
# dtype: int64

# Filling missing values for 'keep_alive_session' with mode imputer
mode_value = df['keep_alive_session'].mode()[0]
df['keep_alive_session'].fillna(mode_value, inplace=True)

# Specify the attributes for which you want to perform median imputation
attributes_to_impute = ['device_fraud_count', 'month', 'credit_risk_score']

# Convert the dataframe to numeric to avoid 'NAType' error
df[attributes_to_impute] = df[attributes_to_impute].apply(pd.to_numeric, errors='coerce')

# Initialize the SimpleImputer with 'median' strategy
imputer = SimpleImputer(strategy='median')

# Iterate through each attribute and perform median imputation
for attribute in attributes_to_impute:
    df[attribute] = imputer.fit_transform(df[[attribute]])

# Verify that missing values have been filled
print("Number of missing values after imputation:")
print(df[attributes_to_impute].isnull().sum())

#OUTPUT
# Number of missing values after imputation:
# device_fraud_count    0
# month                 0
# credit_risk_score     0
# dtype: int64


# Filling missing values for 'keep_alive_session' with mode imputer
mode_value = df['keep_alive_session'].mode()[0]
df['keep_alive_session'].fillna(mode_value, inplace=True)

# Specify the attributes for which you want to perform median imputation
attributes_to_impute = ['device_fraud_count', 'month', 'credit_risk_score', 'prev_address_months_count', 'current_address_months_count', 'bank_months_count', 'session_length_in_minutes', 'device_distinct_emails_8w']

# Convert the dataframe to numeric to avoid 'NAType' error
df[attributes_to_impute] = df[attributes_to_impute].apply(pd.to_numeric, errors='coerce')

# Initialize the SimpleImputer with 'median' strategy
imputer = SimpleImputer(strategy='median')

# Iterate through each attribute and perform median imputation
for attribute in attributes_to_impute:
    df[attribute] = imputer.fit_transform(df[[attribute]])

# Verify that missing values have been filled
print("Number of missing values after imputation:")
print(df[attributes_to_impute].isnull().sum())


#OUTPUT
# Number of missing values after imputation:
# device_fraud_count              0
# month                           0
# credit_risk_score               0
# prev_address_months_count       0
# current_address_months_count    0
# bank_months_count               0
# session_length_in_minutes       0
# device_distinct_emails_8w       0
# dtype: int64


import matplotlib.pyplot as plt
# Plot histograms
df.hist(bins=50, figsize=(20, 15))

# Specify the file path to save the plot
file_path = "histogram_plot.png"  # You can change the file extension as needed

# Save the plot as a file
# plt.savefig(file_path)

# Show the plot
plt.show()

#OUTPUT - attached as file 'histogram_plot.png'


import matplotlib.pyplot as plt
import seaborn as sns

# Print out the column names of data
print(df.columns)

# Corrected numerical columns
numerical_columns = ['income', 'name_email_similarity', 'prev_address_months_count', 'current_address_months_count',
                     'customer_age', 'days_since_request', 'intended_balcon_amount', 'zip_count_4w', 'velocity_6h',
                     'velocity_24h', 'velocity_4w', 'bank_branch_count_8w', 'date_of_birth_distinct_emails_4w',
                     'credit_risk_score', 'bank_months_count', 'proposed_credit_limit', 'session_length_in_minutes',
                     'device_fraud_count', 'month', 'fraud_bool']

# Compute the correlation matrix
correlation_matrix = df[numerical_columns].corr()

# Plot the correlation matrix as a heatmap
plt.figure(figsize=(12, 10))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Correlation Matrix of Numerical Features')

# Specify the file path to save the plot
file_path = "correlation_heatmap.png"  # You can change the file extension as needed

# Save the plot as a file - done
# plt.savefig(file_path)

# Show the plot
plt.show()

#OUTPUT - attached in the file as 'correlation_heatmap.png'

import pandas as pd
import matplotlib.pyplot as plt

# Assuming 'df' is your DataFrame containing the data
# Define numerical features
numerical_features = ['income', 'name_email_similarity', 'prev_address_months_count', 'current_address_months_count',
                      'customer_age', 'days_since_request', 'intended_balcon_amount', 'zip_count_4w', 'velocity_6h',
                      'velocity_24h', 'velocity_4w', 'bank_branch_count_8w', 'date_of_birth_distinct_emails_4w',
                      'credit_risk_score', 'bank_months_count', 'proposed_credit_limit', 'session_length_in_minutes',
                      'device_fraud_count', 'month']

summary_stats = df.groupby('fraud_bool').describe()

# Loop through each numerical feature
for feature in numerical_features:
    # Create box plot
    df.boxplot(column=feature, by='fraud_bool', figsize=(8, 6))
    plt.title(f'Box Plot of {feature} by Target Variable (fraud_bool)')
    plt.xlabel('fraud_bool')
    plt.ylabel(feature)

    # Specify the file path to save the plot
    file_path = f"box_plot_{feature}.png"  # You can change the file extension as needed

    # Save the plot as a file - done saved in folder BoxPlots
    # plt.savefig(file_path)

    # Show the plot
    plt.show()


# ADASYN
X = df.drop(columns=['fraud_bool'])  # Drop the target variable to get the features
y = df['fraud_bool']  # Get the target variable

# Now, X contains the features and y contains the target variable

from sklearn.model_selection import train_test_split, StratifiedKFold
from category_encoders import TargetEncoder
from imblearn.over_sampling import ADASYN
from imblearn.under_sampling import NearMiss

# Assuming 'X' is your feature dataset and 'y' is your target variable
print("Computing Target Encoding")
# Target encoding
target_encoder = TargetEncoder()

X_encoded = target_encoder.fit_transform(X, y)

# Split the original dataset into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X_encoded, y, test_size=0.2, random_state=42)

print("Computing ADASYN...")

# Apply oversampling (ADASYN) only to the train set
adasyn = ADASYN(random_state=42)
X_train_oversampled, y_train_oversampled = adasyn.fit_resample(X_train, y_train)

# print('Computing NearMiss')
# Apply undersampling (NearMiss) to both train and test sets
# nearmiss = NearMiss(version=1)
# X_train_balanced, y_train_balanced = nearmiss.fit_resample(X_train_oversampled, y_train_oversampled)
# X_test_balanced, y_test_balanced = nearmiss.fit_resample(X_test, y_test)

# Now you can use X_train_balanced, y_train_balanced for training your model
# and X_test_balanced, y_test_balanced for testing/evaluating your model

#print('Computing Stratified KFold Technique')
# Example: Cross-validation
#skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# for train_index, val_index in skf.split(X_train_balanced, y_train_balanced):
#     X_train_cv, X_val_cv = X_train_balanced.iloc[train_index], X_train_balanced.iloc[val_index]
#     y_train_cv, y_val_cv = y_train_balanced.iloc[train_index], y_train_balanced.iloc[val_index]

    # Your model training and evaluation code here
    # e.g., model.fit(X_train_cv, y_train_cv), model.predict(X_val_cv), etc.
print('Complete.')


# from catboost import CatBoostClassifier

# # Initialize CatBoost model
# cat_model = CatBoostClassifier()

# # Train the model
# cat_model.fit(x_train_oversampled ,y_train_oversampled )

# # Make predictions
# cat_pred = cat_model.predict_proba(X_test)[:, 1]


import xgboost as xgb
from sklearn.metrics import roc_auc_score
# Initialize XGBoost model
xgb_model = xgb.XGBClassifier()

# # Train the model
xgb_model.fit(X_train, y_train)

# # Make predictions
xgb_pred = xgb_model.predict_proba(X_test)[:, 1]


# import lightgbm as lgb

# # Initialize LightGBM model
# lgb_model = lgb.LGBMClassifier()

# # Train the model
# lgb_model.fit(X_train, y_train)

# # Make predictions
# lgb_pred = lgb_model.predict_proba(X_test)[:, 1]

# Calculate ROC-AUC for XGBoost
xgb_auc = roc_auc_score(y_test, xgb_pred)
print("XGBoost ROC-AUC:", xgb_auc)